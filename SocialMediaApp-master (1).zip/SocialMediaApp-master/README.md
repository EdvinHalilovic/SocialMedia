# SocialMediaApp
Social Media App project for Web development course - 2022
